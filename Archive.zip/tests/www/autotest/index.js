window.onload = function() {
  addListenerToClass('backBtn', backHome);
}

